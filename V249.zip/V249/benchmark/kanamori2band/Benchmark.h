#ifndef BENCHMARK_BENCHMARK_H
#define BENCHMARK_BENCHMARK_H

#include "Utilities.h"
#include "Kanamori.h"
#include "Functions.h"
#include "Hyb.h"
#include "../../include/linalg/Operators.h"
#include "../../include/atomic/Generate.h"
#include "../../include/atomic/Tensor.h"


template<typename Value>
void make_benchmark()
{
    using namespace benchmark;
    
    
    double const U = 4, J = U/4., lambda = std::sqrt(U), beta = 10, mu = 3./2.*U - 3.*J, eloc = .0, ebath = .0;
    
    
    auto const loc = get_matrix<Value>
    ({
        {  eloc,    .0,    .0,    .0},
        {    .0, -eloc,    .0,    .0},
        {    .0,    .0,  eloc,    .0},
        {    .0,    .0,    .0, -eloc}
    });
    
    Kanamori interaction(loc.I(), U, J);
    
    
    auto const hyb = get_matrix<Value>
    ({
        {  lambda,      .0,      .0,      .0  },
        {      .0,  lambda,      .0,      .0  },
        {      .0,      .0,  lambda,      .0  },
        {      .0,      .0,      .0,  lambda  }
    });
    
    auto const bath = get_matrix<Value>
    ({
        {  ebath,     .0,     .0,     .0  },
        {     .0, -ebath,     .0,     .0  },
        {     .0,     .0,  ebath,     .0  },
        {     .0,     .0,     .0, -ebath  }
    });
    
    
    
    
    jsx::value jParams, jHloc, jOperators;
    
    {
        auto const function = get_hyb(beta, 50, hyb, bath);
        
        jsx::value jFunctions = jsx::object_t
        {
            { "A", function[0][0] },
            { "B", function[1][1] }
        };
        
        mpi::write(jFunctions, "hyb.json");
        
        
        jParams = jsx::object_t
        {
            { "hloc", jsx::object_t
                {
                    { "one body", pretty(loc) },
                    { "two body", get_two_body<Value>(loc.I(), interaction) }
                }
            },
            { "hybridisation", jsx::object_t
                {
                    {  "matrix", jsx::array_t
                        {
                            jsx::array_t{ "A",  "",  "",  "" },
                            jsx::array_t{  "", "B",  "",  "" },
                            jsx::array_t{  "",  "", "A",  "" },
                            jsx::array_t{  "",  "",  "",  "B"}
                        }
                    },
                    {  "functions",  "hyb.json" }
                }
            },
            { "mu", mu },
            { "beta", beta },
            { "thermalisation time", 15 },
            { "measurement time", 45 },
            { "complex", std::is_same<Value, complex>::value },
            { "partition", jsx::object_t
                {
                    { "quantum numbers", jsx::object_t
                        {
                            { "N", jsx::array_t{1., 1., 1., 1.} },
                            { "Sz", jsx::array_t{.5, .5, -.5, -.5} }
                        }
                    },
                    { "green basis", "matsubara" },
                    { "green matsubara cutoff", 25 },
                    { "green bulla", false },
                    { "quantum number susceptibility", true },
                    { "occupation susceptibility direct", true },
                    { "occupation susceptibility bulla", false },
                    { "susceptibility cutoff", 50 },
                    { "susceptibility tail", 200 }
                }
            }
        };
        
        
        jsx::value jTensor = jsx::object_t{
            { "one body", pretty(get_one_body(loc, mu, hyb, bath)) },
            { "two body", get_two_body<Value>(loc.I() + bath.I(), interaction) }
        };
        
        jHloc = ga::construct_hloc<Value>(jTensor);
        
        
        jsx::value jAnnihilation = ga::construct_annihilation_operators<Value>(jHloc);
        

        jOperators = jsx::array_t(2*loc.I());
        
        for(int i = 0; i < loc.I(); ++i) {
            jOperators(2*i    ) = jAnnihilation(i);
            jOperators(2*i + 1) = linalg::conj<Value>(jAnnihilation(i));
        }

    }
    
    
    {
        
        int const N = 50;
        
        
        jsx::value jBullaOperators = jsx::array_t(jOperators.size());
        
        for(int i = 0; i < jOperators.size()/2; ++i) {
            linalg::mult<Value>('n', 'n',  1., jOperators(2*i), jHloc("interaction"), .0, jBullaOperators(2*i));
            linalg::mult<Value>('n', 'n', -1., jHloc("interaction"), jOperators(2*i), 1., jBullaOperators(2*i));
            
            jBullaOperators(2*i + 1) = linalg::conj<Value>(jBullaOperators(2*i));
        }
        
        
        make_green<Value>(beta, jHloc, N, jOperators, jOperators, "ed_green.json");
        
        make_green<Value>(beta, jHloc, N, jBullaOperators, jOperators, "ed_green_impr.json");
        
        jParams["green"] = jsx::object_t
        {
            { "basis", "matsubara" },
            { "cutoff", N },
            { "meas", jsx::array_t{"", "impr", "imprsum"} }
        };
        
    }
    
    
    {
        
        int const M = 50;
        
        
        jsx::value jBilinears = jsx::array_t(jOperators.size(), jsx::array_t(jOperators.size()));
        
        for(int i = 0; i < jOperators.size(); ++i)
            for(int j = 0; j < jOperators.size(); ++j)
                linalg::mult<Value>('n', 'n', 1., jOperators(i), jOperators(j), .0, jBilinears(i)(j));
        
        
        make_susc<Value, 1, 0>(beta, jHloc, M, jBilinears, jBilinears, "ed_susc_ph.json");
        
        jParams["susc_ph"] = jsx::object_t
        {
            { "basis", "matsubara" },
            { "cutoff", M }
        };
        
        
        make_susc<Value, 0, 0>(beta, jHloc, M, jBilinears, jBilinears, "ed_susc_pp.json");
        
        jParams["susc_pp"] = jsx::object_t
        {
            { "basis", "matsubara" },
            { "cutoff", M }
        };
        
    }
    
    
    {
        
        int const N = 9, M = 20;
        
        
        jsx::value jBilinears = jsx::array_t(jOperators.size(), jsx::array_t(jOperators.size()));
        
        for(int i = 0; i < jOperators.size(); ++i)
            for(int j = 0; j < jOperators.size(); ++j)
                linalg::mult<Value>('n', 'n', 1., jOperators(i), jOperators(j), .0, jBilinears(i)(j));
        
        
        jsx::value jBullaOperators = jsx::array_t(jOperators.size());
        
        for(int i = 0; i < jOperators.size()/2; ++i) {
            linalg::mult<Value>('n', 'n',  1., jOperators(2*i), jHloc("interaction"), .0, jBullaOperators(2*i));
            linalg::mult<Value>('n', 'n', -1., jHloc("interaction"), jOperators(2*i), 1., jBullaOperators(2*i));
            
            jBullaOperators(2*i + 1) = linalg::conj<Value>(jBullaOperators(2*i));
        }
        
        
        make_hedin<Value, 0, 1>(beta, jHloc, N, M, jOperators, jOperators, jBilinears, "ed_hedin_ph.json");
        
        make_hedin<Value, 0, 1>(beta, jHloc, N, M, jBullaOperators, jOperators, jBilinears, "ed_hedin_ph_impr.json");
        
        jParams["hedin_ph"] = jsx::object_t
        {
            { "basis", "matsubara" },
            { "fermion cutoff", N },
            { "boson cutoff", M },
            { "meas", jsx::array_t{"", "impr", "imprsum"} }
        };
        
        
        make_hedin<Value, 0, 0>(beta, jHloc, N, M, jOperators, jOperators, jBilinears, "ed_hedin_pp.json");
        
        make_hedin<Value, 0, 0>(beta, jHloc, N, M, jBullaOperators, jOperators, jBilinears, "ed_hedin_pp_impr.json");
        
        jParams["hedin_pp"] = jsx::object_t
        {
            { "basis", "matsubara" },
            { "fermion cutoff", N },
            { "boson cutoff", M },
            { "meas", jsx::array_t{"", "impr", "imprsum"} }
        };
        
    }
    
    
    {
        
        int const N = 8, M = 16;
        
        
        jsx::value jBullaOperators = jsx::array_t(jOperators.size());
        
        for(int i = 0; i < jOperators.size()/2; ++i) {
            linalg::mult<Value>('n', 'n',  1., jOperators(2*i), jHloc("interaction"), .0, jBullaOperators(2*i));
            linalg::mult<Value>('n', 'n', -1., jHloc("interaction"), jOperators(2*i), 1., jBullaOperators(2*i));
            
            jBullaOperators(2*i + 1) = linalg::conj<Value>(jBullaOperators(2*i));
        }
        
        
        make_vertex<Value>(beta, jHloc, N, N, M, jOperators, jOperators, jOperators, jOperators, "ed_vertex.json");
        
        make_vertex<Value>(beta, jHloc, N, N, M, jBullaOperators, jOperators, jOperators, jOperators, "ed_vertex_impr.json");
        
        jParams["vertex"] = jsx::object_t
        {
            { "basis", "matsubara" },
            { "fermion cutoff", N },
            { "boson cutoff", M },
            { "meas", jsx::array_t{"", "impr", "imprsum"} }
        };
        
    }
    
    
    mpi::write(jParams, "params.json");
    
};

#endif
