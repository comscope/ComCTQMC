#ifndef BENCHMARK_KANAMORI_H
#define BENCHMARK_KANAMORI_H

#include <stdexcept>

namespace benchmark {
    
    struct Kanamori {
        Kanamori() = delete;
        Kanamori(int N, double U, double J) :
        n_(N/2),
        U_(U),
        J_(J),
        Up_(U_ - 2.*J_) {
            if(N%2) throw std::runtime_error("Kanamori: wrong dimension!");
        }
        ~Kanamori() = default;
        
        double operator()(int f1, int f2, int f3, int f4) const {
            if(!((f1/n_ == f4/n_) && (f2/n_ == f3/n_))) return .0;
            
            int const m1 = f1%n_, m2 = f2%n_, m3 = f3%n_, m4 = f4%n_;
            
            if(m1 == m2 && m3 == m4 && m1 == m3) return U_;
            if(m1 == m4 && m2 == m3 && m1 != m2) return Up_;
            if(m1 == m3 && m2 == m4 && m1 != m2) return J_;
            if(m1 == m2 && m3 == m4 && m1 != m3) return J_;
            
            return .0;
        };
        
        int N() const {
            return 2*n_;
        };
        
    private:
        int const n_;
        double const U_, J_, Up_;
    };
    
}

#endif
