#ifndef BENCHMARK_GENERIC_H
#define BENCHMARK_GENERIC_H


#include "Zahl.h"
#include "../../include/io/Vector.h"
#include "../../include/io/Matrix.h"


namespace benchmark {
    
    struct Energy {
        int type;
        complex val;
        Zahl<double> exp;
    };
    
    Energy operator+(Energy const& e1, Energy const& e2) {
        return Energy{e1.type*e2.type, e1.val + e2.val, e1.exp*e2.exp};
    };
    
    Energy operator-(Energy const& e1, Energy const& e2) {
        return Energy{e1.type*e2.type, e1.val - e2.val, e1.exp/e2.exp};
    };
    
    Energy frequency(int n, double beta) {
        return Energy{n%2 ? -1 : 1, {.0, n*M_PI/beta}, 1.};
    };
    
    using Energies = std::vector<Energy>;
    
    
    
    
    template<std::size_t n>
    struct Integrate {
        template<typename... Rest>
        static Zahl<complex> apply(double beta, Energy a, Energy b, Rest... rest) {
            return std::abs(a.val*beta) > 1.e-5 ?
            1./a.val*(Integrate<n>::apply(beta, a + b, rest...) - complex{n}*Integrate<n - 1>::iterate(beta, a, b, rest...)) :
            Integrate<n + 1>::apply(beta, b, rest...)/complex{n + 1.} + a.val*Integrate<n + 2>::apply(beta, b, rest...)/complex{n + 2.};
        };
        
        static Zahl<complex> apply(double beta, Energy a) {
            return std::abs(a.val*beta) > 1.e-5 ?
            1./a.val*(a.type*a.exp*std::pow(beta, n) - complex{n}*Integrate<n - 1>::apply(beta, a)) :
            std::pow(beta, n + 1)/complex{n + 1.} + a.val*std::pow(beta, n + 2)/complex{n + 2.};
        };
        
        template<typename... Rest>
        static Zahl<complex> iterate(double beta, Energy a, Energy b, Rest... rest) {
            return 1./a.val*(Integrate<n>::apply(beta, a + b, rest...) - complex{n}*Integrate<n - 1>::iterate(beta, a, b, rest...));
        };
    };
    
    template<>
    struct Integrate<0> {
        template<typename... Rest>
        static Zahl<complex> apply(double beta, Energy a, Energy b, Rest... rest) {
            return std::abs(a.val*beta) > 1.e-5 ?
            1./a.val*(Integrate<0>::apply(beta, a + b, rest...) - Integrate<0>::apply(beta, b, rest...)) :
            Integrate<1>::apply(beta, b, rest...) + a.val*Integrate<2>::apply(beta, b, rest...)/complex{2.};
        };
        
        static Zahl<complex> apply(double beta, Energy a) {
            return std::abs(a.val*beta) > 1.e-5 ?
            1./a.val*(a.type*a.exp - 1.) :
            complex{beta} + a.val*complex{beta*beta}/complex{2.};
        };
        
        template<typename... Rest>
        static Zahl<complex> iterate(double beta, Energy a, Energy b, Rest... rest) {
            return 1./a.val*(Integrate<0>::apply(beta, a + b, rest...) - Integrate<0>::apply(beta, b, rest...));
        };
    };
    
    
    
    
    template<typename Value, typename... Rest>
    Zahl<complex> sum(double beta, std::size_t iPrev, Energy const& ePrev, int f, io::Matrix<Value> const& mat, std::size_t iFirst, Energy const& eFirst, Rest&&... rest) {
        return complex{mat(iFirst, iPrev)}/eFirst.exp*Integrate<0>::apply(beta, std::forward<Rest>(rest)..., frequency(f, beta) + (eFirst - ePrev));
    };
    
    template<typename Value, typename... Rest>
    Zahl<complex> sum(double beta, std::size_t iPrev, Energy const& ePrev, int f, io::Matrix<Value> const& mat, Energies const& eSector, Rest&&... rest) {
        Zahl<complex> acc = complex{.0};
        for(std::size_t i = 0; i < eSector.size(); ++i)
            acc += complex{mat(i, iPrev)}*sum(beta, i, eSector[i], std::forward<Rest>(rest)..., frequency(f, beta) + (eSector[i] - ePrev));
        return acc;
    };
    
    
    
    
    template<typename Value, typename... Rest>
    Zahl<complex> sector(std::vector<Energies> const& energies, std::int64_t sec, double beta, std::int64_t sec0, std::vector<Energy> const& eSector0, io::Matrix<Value> const& mat, std::vector<Energy> const& eSector1, Rest&&... rest) {
        Zahl<complex> acc = complex{.0};
        if(sec0 == sec)
            for(std::size_t i0 = 0; i0 < eSector0.size(); ++i0)
                for(std::size_t i1 = 0; i1 < eSector1.size(); ++i1)
                    acc += complex{mat(i1, i0)}*sum(beta, i1, eSector1[i1], std::forward<Rest>(rest)..., i0, eSector0[i0]);
        return acc;
    };
    
    template<typename Value, typename... Rest>
    Zahl<complex> sector(std::vector<Energies> const& energies, std::int64_t sec, int f, jsx::value& jOp, Rest&&... rest) {
        if(!jOp(sec)("target").is<jsx::null_t>())
            return sector<Value>(energies, jOp(sec)("target").int64(), std::forward<Rest>(rest)..., energies[sec], f, jsx::at<io::Matrix<Value>>(jOp(sec)("matrix")));
        return complex{.0};
    };
    
    
    
    
    template<typename Value, typename... Rest>
    complex evaluate(double beta, jsx::value& jHloc, jsx::value& jOp, Rest&&... rest) {
        Zahl<double> Z = .0;
        
        std::vector<Energies> energies;
        for(auto& jEnergies : jHloc("eigen values").array()) {
            Energies eSector;
            for(auto e : jsx::at<io::rvec>(jEnergies)) {
                Z += exp(-beta*e);  eSector.push_back({1, e, exp(beta*e)});
            }
            energies.push_back(eSector);
        }
        
        Zahl<complex> acc = complex{.0};
        for(std::int64_t sec = 0; sec < jOp.size(); ++sec)
            if(!jOp(sec)("target").is<jsx::null_t>())
                acc += sector<Value>(energies, jOp(sec)("target").int64(), std::forward<Rest>(rest)..., beta, sec, energies[sec], jsx::at<io::Matrix<Value>>(jOp(sec)("matrix")));
        
        return (acc/Z).get();
    };
    
    
    
    
    template<typename Value>
    complex eval_green(double beta, jsx::value& jHloc, int n, jsx::value& jOp1, jsx::value& jOp2) {
        return -evaluate<Value>(beta, jHloc, jOp2, (2*n + 1), jOp1);
    };
    
    
    template<typename Value>
    complex eval_susc(double beta, jsx::value& jHloc, int m, jsx::value& jBilinear1, jsx::value& jBilinear2) {
        return evaluate<Value>(beta, jHloc, jBilinear2, 2*m, jBilinear1);
    };
    
    
    template<typename Value>
    complex eval_hedin(double beta, jsx::value& jHloc, int n, int m, jsx::value& jOp1, jsx::value& jOp2, jsx::value& jBilinear) {
        int const f1 = 2*n + 1, f2 = -(2*n + 1) - 2*m;
        
        return + evaluate<Value>(beta, jHloc, jBilinear, f2, jOp2, f1, jOp1)
               - evaluate<Value>(beta, jHloc, jBilinear, f1, jOp1, f2, jOp2);
    };
    
    
    template<typename Value>
    complex eval_vertex(double beta, jsx::value& jHloc, int n1, int n2, int m, jsx::value& jOp1, jsx::value& jOp2, jsx::value& jOp3, jsx::value& jOp4) {
        int const f1 = 2*n1 + 1, f2 = -(2*n1 + 1) - 2*m, f3 = (2*n2 + 1) + 2*m;
        
        return + evaluate<Value>(beta, jHloc, jOp4, f3, jOp3, f2, jOp2, f1, jOp1)
               - evaluate<Value>(beta, jHloc, jOp4, f2, jOp2, f3, jOp3, f1, jOp1)
               - evaluate<Value>(beta, jHloc, jOp4, f3, jOp3, f1, jOp1, f2, jOp2)
               + evaluate<Value>(beta, jHloc, jOp4, f1, jOp1, f3, jOp3, f2, jOp2)
               + evaluate<Value>(beta, jHloc, jOp4, f2, jOp2, f1, jOp1, f3, jOp3)
               - evaluate<Value>(beta, jHloc, jOp4, f1, jOp1, f2, jOp2, f3, jOp3);
    };
    
}

#endif


