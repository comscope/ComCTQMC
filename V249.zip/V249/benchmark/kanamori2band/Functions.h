#ifndef BENCHMARK_FUNCTIONS_H
#define BENCHMARK_FUNCTIONS_H


#include "Generic.h"


namespace benchmark {
    
    jsx::value get_non_zero(std::map<std::string, io::cvec>& input, std::size_t const size) {
        for(auto& entry : input)
            mpi::gather(entry.second, mpi::master);
        
        jsx::value output;
        
        if(mpi::rank() == mpi::master) {
            for(auto& entry : input) {
                entry.second.resize(size);
                
                double temp = .0;
                for(auto const& x : entry.second)
                    temp += std::abs(x);
                
                if(temp/size > 1.e-10)
                    output[entry.first] = std::move(entry.second);
            }
        }
        
        return output;
    };
    
    
    
    
    template<typename Value>
    void make_green(double beta, jsx::value& jHloc, int const N, jsx::value& jOperators1, jsx::value& jOperators2, std::string const name) {
        int const flavors = jOperators1.size();
        
        int const size = N;
        int const rank = mpi::rank();
        int const chunk = (size + mpi::number_of_workers() - 1)/mpi::number_of_workers();
        
        std::map<std::string, io::cvec> green;
        
        for(int index = chunk*rank; index < chunk*(rank + 1); ++index) {
            int const n = (index%size)%N;
            
            std::cout << n << std::endl;
            
            for(int op1 = 0; op1 < flavors; op1 += 2)
                for(int op2 = 1; op2 < flavors; op2 += 2) {
                    auto const entry = std::to_string(op1) + "_" + std::to_string(op2);
                            
                    green[entry].push_back(eval_green<Value>(beta, jHloc, n, jOperators1(op1), jOperators2(op2)));
                }
        }
        
        mpi::write(get_non_zero(green, size), name);
    }
    
    
    
    
    template<typename Value, std::size_t type1, std::size_t type2>
    void make_susc(double beta, jsx::value& jHloc, int const M, jsx::value& jBilinears1, jsx::value& jBilinears2, std::string const name) {
        int const flavors = jBilinears1.size();
        
        int const size = M;
        int const rank = mpi::rank();
        int const chunk = (size + mpi::number_of_workers() - 1)/mpi::number_of_workers();
        
        std::map<std::string, io::cvec> susc;
        
        for(int index = chunk*rank; index < chunk*(rank + 1); ++index) {
            int const m = (index%size)%M;
            
            std::cout << m << std::endl;
            
            for(int op1 = type1; op1 < flavors; op1 += 2)
                for(int op2 = type2; op2 < flavors; op2 += 2)
                    for(int op3 = 1 - type2; op3 < flavors; op3 += 2)
                        for(int op4 = 1 - type1; op4 < flavors; op4 += 2) {
                            auto const entry = std::to_string(op1) + "_" + std::to_string(op2) + "_" + std::to_string(op3) + "_" + std::to_string(op4);
                            
                            susc[entry].push_back(eval_susc<Value>(beta, jHloc, m, jBilinears1(op1)(op2), jBilinears2(op3)(op4)));
                        }
        }
        
        mpi::write(get_non_zero(susc, size), name);
    }
    
    
    
    
    template<typename Value, std::size_t type1, std::size_t type2>
    void make_hedin(double beta, jsx::value& jHloc, int const N, int const M, jsx::value& jOperators1, jsx::value& jOperators2, jsx::value& jBilinears, std::string const name) {
        int const flavors = jOperators1.size();
        
        int const size = 2*N*M;
        int const rank = mpi::rank();
        int const chunk = (size + mpi::number_of_workers() - 1)/mpi::number_of_workers();
        
        std::map<std::string, io::cvec> hedin;
        
        for(int index = chunk*rank; index < chunk*(rank + 1); ++index) {
            int const n = (index%size)%(2*N) - N;
            int const m = (index%size)/(2*N);
            
            std::cout << n << " " << m << std::endl;
            
            for(int op1 = type1; op1 < flavors; op1 += 2)
                for(int op2 = type2; op2 < flavors; op2 += 2)
                    for(int op3 = 1 - type1; op3 < flavors; op3 += 2)
                        for(int op4 = 1 - type2; op4 < flavors; op4 += 2) {
                            auto const entry = std::to_string(op1) + "_" + std::to_string(op2) + "_" + std::to_string(op3) + "_" + std::to_string(op4);

                            hedin[entry].push_back(eval_hedin<Value>(beta, jHloc, n, m, jOperators1(op1), jOperators2(op2), jBilinears(op3)(op4)));
                        }
        }
        
        mpi::write(get_non_zero(hedin, size), name);
        
    }
    
    
    
    
    template<typename Value>
    void make_vertex(double beta, jsx::value& jHloc, int const N1, int const N2, int const M, jsx::value& jOperators1, jsx::value& jOperators2, jsx::value& jOperators3, jsx::value& jOperators4, std::string const name) {
        int const flavors = jOperators1.size();
        
        int const size = 4*N1*N2*M;
        int const rank = mpi::rank();
        int const chunk = (size + mpi::number_of_workers() - 1)/mpi::number_of_workers();
        
        std::map<std::string, io::cvec> vertex;
        
        for(int index = chunk*rank; index < chunk*(rank + 1); ++index) {
            int const n1 = (index%size)%(2*N1) - N1;
            int const n2 = ((index%size)/(2*N1))%(2*N2) - N2;
            int const m  = ((index%size)/(4*N1*N2))%M;
            
            std::cout << n1 << " " << n2 << " " << m << std::endl;
            
            for(int op1 = 0; op1 < flavors; op1 += 2)
                for(int op2 = 1; op2 < flavors; op2 += 2)
                    for(int op3 = 0; op3 < flavors; op3 += 2)
                        for(int op4 = 1; op4 < flavors; op4 += 2) {
                            auto const entry = std::to_string(op1) + "_" + std::to_string(op2) + "_" + std::to_string(op3) + "_" + std::to_string(op4);

                            vertex[entry].push_back(eval_vertex<Value>(beta, jHloc, n1, n2, m, jOperators1(op1), jOperators2(op2), jOperators3(op3), jOperators4(op4)));
                        }
            
        }
        
        mpi::write(get_non_zero(vertex, size), name);
        
    }
    
}


#endif
