#ifndef BENCHMARK_INCLUDE_GREEN_H
#define BENCHMARK_INCLUDE_GREEN_H


#include "Zahl.h"
#include "../../include/atomic/Generate.h"
#include "../../include/atomic/Tensor.h"
#include "../../include/io/Matrix.h"
#include "../../include/mpi/Utilities.h"


namespace benchmark {
    
    template<typename Value>
    Value get_green_tau(double const beta, double const tau, jsx::value& jHloc, jsx::value& jA, jsx::value& jB) {
        Zahl<double> Z = .0;
        
        for(auto const& eigenvalues : jHloc("eigen values").array())
            for(auto const& eigenvalue : jsx::at<io::rvec>(eigenvalues))
                Z += exp(-beta*eigenvalue);
                
        
        if(jA.size() != jB.size())
            throw std::runtime_error("missmatch in size of A and B");
        
        
        Zahl<Value> green = Value(.0);
        
        for(std::int64_t s = 0; s < jA.size(); ++s)
            if(!jA(s)("target").is<jsx::null_t>() && !jB(s)("target").is<jsx::null_t>()) {
                if(jA(s)("target").int64() == jB(s)("target").int64()) {
                    int const t = jA(s)("target").int64();
                    
                    auto const& A = jsx::at<io::Matrix<Value>>(jA(s)("matrix"));
                    auto const& B = jsx::at<io::Matrix<Value>>(jB(s)("matrix"));
                    
                    auto const& eig_s = jsx::at<io::rvec>(jHloc("eigen values")(s));
                    auto const& eig_t = jsx::at<io::rvec>(jHloc("eigen values")(t));

                    for(int n = 0; n < A.I(); ++n)
                        for(int m = 0; m < A.J(); ++m)
                            green += exp(-(beta - tau)*eig_t[n] - tau*eig_s[m])*A(n, m)*conj(B(n, m)); 
                }
            }
        
        green /= Z;
        
        return -green.get();
    }
    

    template<typename Value>
    complex get_green_matsubara(double const beta, std::complex<double> const z, jsx::value& jHloc, jsx::value& jA, jsx::value& jB) {
        Zahl<double> Z = .0;
        
        for(auto const& eigenvalues : jHloc("eigen values").array())
            for(auto const& eigenvalue : jsx::at<io::rvec>(eigenvalues))
                Z += exp(-beta*eigenvalue);
        
        
        if(jA.size() != jB.size())
            throw std::runtime_error("missmatch in size of A and B");
        
        
        Zahl<complex> green(complex(.0));
        
        for(std::int64_t s = 0; s < jA.size(); ++s)
            if(!jA(s)("target").is<jsx::null_t>() && !jB(s)("target").is<jsx::null_t>()) {
                if(jA(s)("target").int64() == jB(s)("target").int64()) {
                    int const t = jA(s)("target").int64();
                    
                    auto const& A = jsx::at<io::Matrix<Value>>(jA(s)("matrix"));
                    auto const& B = jsx::at<io::Matrix<Value>>(jB(s)("matrix"));
                    
                    auto const& eig_s = jsx::at<io::rvec>(jHloc("eigen values")(s));
                    auto const& eig_t = jsx::at<io::rvec>(jHloc("eigen values")(t));
                    
                    for(int n = 0; n < A.I(); ++n)
                        for(int m = 0; m < A.J(); ++m)
                            green += (exp(-eig_t[n]*beta) + exp(-eig_s[m]*beta))/(z + eig_t[n] - eig_s[m])*complex(A(n, m)*conj(B(n, m)));
                }
            }
        
        green /= Z;
        
        return green.get();
    }
    
}

#endif
