#ifndef BENCHMARK_INCLUDE_UTILITIES_H
#define BENCHMARK_INCLUDE_UTILITIES_H


#include "Zahl.h"
#include "../../include/atomic/Generate.h"
#include "../../include/atomic/Tensor.h"
#include "../../include/io/Matrix.h"
#include "../../include/mpi/Utilities.h"


namespace benchmark {
    
    template<typename Value, typename Interaction>
    io::Vector<Value> get_two_body(int const N, Interaction const& V) {
        if(N < V.N()) throw std::runtime_error("get_two_body: wrong dimensions!");

        io::Vector<Value> two_body(N*N*N*N, .0);
        
        for(int f1 = 0; f1 < V.N(); ++f1)
            for(int f2 = 0; f2 < V.N(); ++f2)
                for(int f3 = 0; f3 < V.N(); ++f3)
                    for(int f4 = 0; f4 < V.N(); ++f4)
                        two_body[N*N*N*f1 +
                                 N*N*f2 +
                                 N*f3 +
                                 f4] = V(f1, f2, f3, f4);

        return two_body;
    }
    
    
    template<typename Value>
    io::Matrix<Value> get_one_body(io::Matrix<Value> loc, double const mu, io::Matrix<Value> hyb, io::Matrix<Value> bath) {
        if(loc.I() != hyb.I()) throw std::runtime_error("loc and hyb not compatible");
        if(bath.J() != hyb.J()) throw std::runtime_error("bath and hyb not compatible");
        
        
        io::Matrix<Value> one_body(loc.I() + bath.I(), loc.J() + bath.J());
        
        
        for(int i = 0; i < loc.I(); ++i)
            for(int j = 0; j < loc.J(); ++j)
                one_body(i, j) = loc(i, j) - (i == j ? mu : .0);
        
        for(int i = 0; i < bath.I(); ++i)
            for(int j = 0; j < bath.J(); ++j)
                one_body(i + loc.I(), j + loc.J()) = bath(i, j);
        
        for(int i = 0; i < hyb.I(); ++i)
            for(int j = 0; j < hyb.J(); ++j) {
                one_body(i, j + loc.J()) =      hyb(i, j) ;
                one_body(j + loc.J(), i) = conj(hyb(i, j));
            }
        
        
        return one_body;
    }
    
    
    
    
    template<typename Value>
    io::Matrix<Value> get_matrix(std::vector<std::vector<Value>> arg) {
        std::size_t const I = arg.size();
        std::size_t const J = I ? arg[0].size() : 0;
        
        io::Matrix<Value> matrix(I, J);
        
        for(std::size_t i = 0; i < I; ++i) {
            if(J != arg[i].size())
                throw std::runtime_error("get_matrix: arg is not a matrix");
            
            for(std::size_t j = 0; j < J; ++j)
                matrix(i, j) = arg[i][j];
        }
        
        return matrix;
    }
    
    
    template<typename Value>
    io::PrettyMatrix<Value> pretty(io::Matrix<Value> arg) {
        io::PrettyMatrix<Value> matrix(arg.I(), arg.J());
        
        for(std::size_t i = 0; i < arg.I(); ++i)
            for(std::size_t j = 0; j < arg.J(); ++j)
                matrix(i, j) = arg(i, j);
        
        return matrix;
    }
    
}

#endif
