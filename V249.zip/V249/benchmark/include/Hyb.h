#ifndef BENCHMARK_INCLUDE_HYB_H
#define BENCHMARK_INCLUDE_HYB_H


#include "Zahl.h"
#include "../../include/atomic/Generate.h"
#include "../../include/atomic/Tensor.h"
#include "../../include/io/Matrix.h"
#include "../../include/mpi/Utilities.h"


namespace benchmark {
    
    template<typename Value>
    std::vector<std::vector<io::cvec>> get_hyb(double beta, double cutoff, io::Matrix<Value> hyb, io::Matrix<Value> bath) {
        if(bath.J() != hyb.J()) throw std::runtime_error("bath and hyb not compatible");
        
        std::size_t const N = std::max(static_cast<std::size_t>((cutoff*beta)/(2.*M_PI)), std::size_t(1));
        
        
        std::vector<io::cmat> matrix_function(N, io::cmat(hyb.I(), hyb.I()));
        
        for(std::size_t n = 0; n < N; ++n) {
            complex const iomega{.0, M_PI*(2*n + 1)/beta};
            
            
            io::cmat chyb(hyb.I(), hyb.J());
            for(std::size_t i = 0; i < hyb.I(); ++i)
                for(std::size_t j = 0; j < hyb.J(); ++j)
                    chyb(i, j) = hyb(i, j);
            
            
            io::cmat ginv_bath(bath.I(), bath.J());
            for(std::size_t i = 0; i < bath.I(); ++i)
                for(std::size_t j = 0; j < bath.J(); ++j)
                    ginv_bath(i, j) = (i == j ? iomega : .0) - bath(i, j);
            io::cmat g_bath = linalg::inv(ginv_bath);
            
            
            io::cmat temp(hyb.I(), bath.J());
            linalg::mult('n', 'n', complex(1.), chyb, g_bath, complex(.0), temp);
            linalg::mult('n', 'c', complex(1.), temp, chyb, complex(.0), matrix_function[n]);
        }
        
        
        std::vector<std::vector<io::cvec>> function_matrix(hyb.I(), std::vector<io::cvec>(hyb.I()));
        
        for(std::size_t i = 0; i < hyb.I(); ++i)
            for(std::size_t j = 0; j < hyb.I(); ++j)
               for(std::size_t n = 0; n < N; ++n)
                   function_matrix[i][j].push_back(matrix_function[n](i, j));
        
        
        return function_matrix;
    }
    
}

#endif
