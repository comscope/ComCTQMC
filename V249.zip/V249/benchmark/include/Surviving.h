#ifndef BENCHMARK_INCLUDE_SURVIVING_H
#define BENCHMARK_INCLUDE_SURVIVING_H


#include "Zahl.h"
#include "../../include/atomic/Generate.h"
#include "../../include/atomic/Tensor.h"
#include "../../include/io/Matrix.h"
#include "../../include/mpi/Utilities.h"


namespace benchmark {
    
    bool surviving(jsx::value& jA, jsx::value& jB) {
        bool is_surviving = false;
        
        for(std::int64_t s = 0; s < jA.size(); ++s)
            if(!jA(s)("target").is<jsx::null_t>() && !jB(s)("target").is<jsx::null_t>()) 
                if(jA(s)("target").int64() == jB(s)("target").int64()) is_surviving = true;
        
        return is_surviving;
    }
    
}

#endif
