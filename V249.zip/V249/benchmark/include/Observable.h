#ifndef BENCHMARK_INCLUDE_OBSERVABLE_H
#define BENCHMARK_INCLUDE_OBSERVABLE_H


#include "Zahl.h"
#include "../../include/atomic/Generate.h"
#include "../../include/atomic/Tensor.h"
#include "../../include/io/Matrix.h"
#include "../../include/mpi/Utilities.h"


namespace benchmark {
    
    template<typename Value>
    Value get_observable(double const beta, jsx::value& jHloc, jsx::value& jObs) {
        Zahl<double> Z = .0;

        for(auto const& eigenvalues : jHloc("eigen values").array())
            for(auto const& eigenvalue : jsx::at<io::rvec>(eigenvalues))
                Z += exp(-beta*eigenvalue);

        Zahl<Value> obs = Value(.0);

        for(std::int64_t s = 0; s < jObs.size(); ++s)
            if(!jObs(s)("target").is<jsx::null_t>())
                if(jObs(s)("target").int64() == s) {
                    auto const& eig = jsx::at<io::rvec>(jHloc("eigen values")(s));
                    auto const& matrix = jsx::at<io::Matrix<Value>>(jObs(s)("matrix"));

                    for(std::size_t n = 0; n < eig.size(); ++n)
                        obs += exp(-eig[n]*beta)*matrix(n, n);
                }

        obs /= Z;
        
        return obs.get();
    }
    
}

#endif
