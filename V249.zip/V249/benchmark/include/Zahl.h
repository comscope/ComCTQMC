#ifndef BENCHMARK_ZAHL_H
#define BENCHMARK_ZAHL_H

#include <vector>
#include <iostream>
#include <fstream>
#include <cmath>
#include <cstring>
#include <complex>
#include <cstdint>
#include <random>
#include <limits>
#include <utility>
#include <stdexcept>


namespace benchmark {
    
    using complex = std::complex<double>;
    
    inline double conj(double arg) { return arg;};
    inline complex conj(complex arg) { return std::conj(arg);};
    
    
    
    template<typename Value> struct Zahl;
    
    template<>
    struct Zahl<double> {
        Zahl() : mantissa_(.0), exponent_(std::numeric_limits<int>::min()) {};
        Zahl(double x, double y = .0) {   // constructs x*exp(y)
            if(std::isfinite(x) && std::isfinite(y)) {
                mantissa_ = std::frexp(x*std::exp(y - M_LN2*(static_cast<int>(y/M_LN2) + 1)), &exponent_);
                mantissa_ != .0 ? exponent_ += static_cast<int>(y/M_LN2) + 1 : exponent_ = std::numeric_limits<int>::min();
            } else
                throw std::runtime_error("ut::Zahl<double>: argument of constructor is not a number");
        };
        Zahl(Zahl const&) = default;
        Zahl(Zahl&&) = default;
        Zahl& operator=(Zahl const&) = default;
        Zahl& operator=(Zahl&&) = default;
        ~Zahl() = default;
        
        Zahl& operator+=(Zahl const& arg) {
            int exp;
            if(exponent_ > arg.exponent_) {
                mantissa_ = std::frexp(mantissa_ + std::ldexp(arg.mantissa_, arg.exponent_ - exponent_), &exp);
                mantissa_ != .0 ? exponent_ += exp : exponent_ = std::numeric_limits<int>::min();
            } else {
                mantissa_ = std::frexp(arg.mantissa_ + std::ldexp(mantissa_, exponent_ - arg.exponent_), &exp);
                mantissa_ != .0 ? exponent_ = arg.exponent_ + exp : exponent_ = std::numeric_limits<int>::min();
            }
            return *this;
        };
        Zahl& operator*=(Zahl const& arg) {
            int exp; mantissa_ = std::frexp(mantissa_*arg.mantissa_, &exp);
            mantissa_ != .0 ? exponent_ += (arg.exponent_ + exp) : exponent_ = std::numeric_limits<int>::min();
            return *this;
        };
        Zahl& operator/=(Zahl const& arg) {
            if(arg.mantissa_ == .0) throw std::runtime_error("ut::Zahl<double>: division by zero");
            
            int exp; mantissa_ = std::frexp(mantissa_/arg.mantissa_, &exp);
            mantissa_ != .0 ? exponent_ += (-arg.exponent_ + exp) : exponent_ = std::numeric_limits<int>::min();
            return *this;
        };
        double get() const {
            return std::ldexp(mantissa_, exponent_);
        };
        Zahl abs() const {
            Zahl temp = *this; temp.mantissa_ = std::abs(temp.mantissa_); return temp;
        };
        
        double mantissa() const { return mantissa_;};
        int exponent() const { return exponent_;};
    private:
        double mantissa_;
        int exponent_;
        
        void set(double mantissa, int exponent) {
            
        }
        
        friend struct Zahl<complex>;
        friend int operator==(Zahl<double> const&, Zahl<double> const&);
        friend int operator<=(Zahl<double> const&, Zahl<double> const&);
        friend Zahl<double> abs(Zahl<double> const&);
    };
    
    inline int operator==(Zahl<double> const& x, Zahl<double> const& y) {   // should this be implemented for complex case as well ?
        return (x.mantissa_ == y.mantissa_)&&(x.exponent_ == y.exponent_);
    }
    
    inline int operator<=(Zahl<double> const& x, Zahl<double> const& y) {
        if(x.mantissa_*y.mantissa_ <= .0 || x.exponent_ == y.exponent_) return x.mantissa_ <= y.mantissa_;
        return x.exponent_ < y.exponent_ ? x.mantissa_ > .0 : x.mantissa_ < .0;
    }
    
    inline Zahl<double> exp(double arg) {
        return arg != -std::numeric_limits<double>::infinity() ? Zahl<double>(1., arg) : Zahl<double>();
    }
    
    inline Zahl<double> operator+(Zahl<double> const& x, Zahl<double> const& y) {
        Zahl<double> temp(x); temp += y; return temp;
    }
    
    inline Zahl<double> operator*(Zahl<double> const& x, Zahl<double> const& y) {
        Zahl<double> temp(x); temp *= y; return temp;
    }
    
    inline Zahl<double> operator/(Zahl<double> const& x, Zahl<double> const& y) {
        Zahl<double> temp(x); temp /= y; return temp;
    }
    
    
    template<>
    struct Zahl<complex> {
        Zahl() : mantissa_(.0), exponent_(std::numeric_limits<int>::min()) {};
        Zahl(complex z, double y = .0) {
            if(std::isfinite(z.real()) && std::isfinite(z.imag()) && std::isfinite(y)) {  //better this way than using constructor of Zahl<double> because of throw
                double const x = std::abs(z);
                mantissa_ = x != .0 ? std::frexp(x*std::exp(y - M_LN2*(static_cast<int>(y/M_LN2) + 1)), &exponent_)*(z/x) : .0;
                mantissa_ != .0 ? exponent_ += static_cast<int>(y/M_LN2) + 1 : exponent_ = std::numeric_limits<int>::min();
            } else
                throw std::runtime_error("ut::Zahl<complex>: argument of constructor is not a number");
        };
        Zahl(Zahl<double> const& arg) : mantissa_(arg.mantissa()), exponent_(arg.exponent()) {}
        Zahl(Zahl const&) = default;
        Zahl(Zahl&&) = default;
        Zahl& operator=(Zahl const&) = default;
        Zahl& operator=(Zahl&&) = default;
        ~Zahl() = default;
        
        Zahl& operator+=(Zahl const& arg) {
            int exp;
            if(exponent_ > arg.exponent_) {
                auto const z = mantissa_ + (arg.mantissa_ != .0 ? arg.mantissa_*std::ldexp(1., arg.exponent_ - exponent_) : .0);
                auto const x = std::abs(z); mantissa_ = x != .0 ? std::frexp(x, &exp)*(z/x) : .0;
                mantissa_ != .0 ? exponent_ += exp : exponent_ = std::numeric_limits<int>::min();
            } else {
                auto const z = arg.mantissa_ + (mantissa_ != .0 ? mantissa_*std::ldexp(1., exponent_ - arg.exponent_) : .0);
                auto const x = std::abs(z); mantissa_ = x != .0 ? std::frexp(x, &exp)*(z/x) : .0;
                mantissa_ != .0 ? exponent_ = arg.exponent_ + exp : exponent_ = std::numeric_limits<int>::min();
            }
            return *this;
        };
        Zahl& operator*=(Zahl const& arg) {
            auto const z = mantissa_*arg.mantissa_; int exp;
            auto const x = std::abs(z); mantissa_ = x != .0 ? std::frexp(x, &exp)*(z/x) : .0;
            mantissa_ != .0 ? exponent_ += (arg.exponent_ + exp) : exponent_ = std::numeric_limits<int>::min();
            return *this;
        };
        Zahl& operator/=(Zahl const& arg) {
            if(arg.mantissa_ == .0) throw std::runtime_error("ut::Zahl<complex>: division by zero");
            
            auto const z = mantissa_/arg.mantissa_; int exp;
            auto const x = std::abs(z); mantissa_ = x != .0 ? std::frexp(x, &exp)*(z/x) : .0;
            mantissa_ != .0 ? exponent_ += (-arg.exponent_ + exp) : exponent_ = std::numeric_limits<int>::min();
            return *this;
        };
        complex get() const {
            return mantissa_*std::ldexp(1., exponent_);
        };
        Zahl<double> abs() const {
            Zahl<double> temp; temp.mantissa_ = std::abs(mantissa_); temp.exponent_ = exponent_; return temp;
        };
        
        complex mantissa() const { return mantissa_;};
        int exponent() const { return exponent_;};
    private:
        complex mantissa_;
        int exponent_;
        
        friend Zahl<double> abs(Zahl const&);
    };
    
    inline Zahl<complex> operator+(Zahl<complex> const& x, Zahl<complex> const& y) {
        Zahl<complex> temp(x); temp += y; return temp;
    }
    
    inline Zahl<complex> operator*(Zahl<complex> const& x, Zahl<complex> const& y) {
        Zahl<complex> temp(x); temp *= y; return temp;
    }
    
    inline Zahl<complex> operator/(Zahl<complex> const& x, Zahl<complex> const& y) {
        Zahl<complex> temp(x); temp /= y; return temp;
    }
    
    
    
    template<typename Value>
    inline Zahl<double> abs(Zahl<Value> const& arg) {
        return arg.abs();
    }
    
}


#endif
