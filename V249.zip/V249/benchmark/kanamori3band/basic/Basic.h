#ifndef BENCHMARK_KANAMORI_BASIC_H
#define BENCHMARK_KANAMORI_BASIC_H

#include "Kanamori.h"
#include "../../include/Utilities.h"
#include "../../include/Surviving.h"
#include "../../include/Green.h"
#include "../../include/Susc.h"
#include "../../include/Hyb.h"
#include "../../include/Observable.h"
#include "../../../include/mpi/Utilities.h"
#include "../../../include/linalg/Operators.h"


template<typename Value>
void make_basic()
{
    using namespace benchmark;
    
    
    double const U = 4, J = U/4., lambda = std::sqrt(U), beta = 10, mu = 5./2.*U - 5.*J, eloc = .0, ebath = .0;
    
    
    auto const loc = get_matrix<Value>
    ({
        {  .0,    .0,    .0,    .0,    .0,    .0},
        {  .0,  eloc,    .0,    .0,    .0,    .0},
        {  .0,    .0, -eloc,    .0,    .0,    .0},
        {  .0,    .0,    .0,    .0,    .0,    .0},
        {  .0,    .0,    .0,    .0,  eloc,    .0},
        {  .0,    .0,    .0,    .0,    .0, -eloc}
    });
    
    Kanamori interaction(loc.I(), U, J);
    
    
    auto const hyb = get_matrix<Value>
    ({
        {  lambda,      .0,      .0,      .0,      .0,      .0},
        {      .0,  lambda,      .0,      .0,      .0,      .0},
        {      .0,      .0,  lambda,      .0,      .0,      .0},
        {      .0,      .0,      .0,  lambda,      .0,      .0},
        {      .0,      .0,      .0,      .0,  lambda,      .0},
        {      .0,      .0,      .0,      .0,      .0,  lambda}
    });
    
    auto const bath = get_matrix<Value>
    ({
        {  .0,     .0,     .0,     .0,     .0,     .0},
        {  .0,  ebath,     .0,     .0,     .0,     .0},
        {  .0,     .0, -ebath,     .0,     .0,     .0},
        {  .0,     .0,     .0,     .0,     .0,     .0},
        {  .0,     .0,     .0,     .0,  ebath,     .0},
        {  .0,     .0,     .0,     .0,     .0, -ebath}
    });

    
    {
        auto const function = get_hyb(beta, 50, hyb, bath);
        
        jsx::value jFunctions = jsx::object_t
        {
            {
                jsx::string_t{"A"}, function[0][0]
            },
            {
                jsx::string_t{"B"}, function[1][1]
            },
            {
                jsx::string_t{"C"}, function[2][2]
            }
        };
        
        mpi::write(jFunctions, "hyb.json");
        
        
        jsx::value jParams = jsx::object_t
        {
            {
                jsx::string_t{"hloc"}, jsx::object_t{
                    {
                        jsx::string_t{"one body"}, pretty(loc)
                    }, {
                        jsx::string_t{"two body"}, get_two_body<Value>(loc.I(), interaction)
                    }
                }
            }, {
                jsx::string_t{"hybridisation"}, jsx::object_t{
                    {
                        jsx::string_t{"matrix"}, jsx::array_t{
                            jsx::array_t{
                                jsx::string_t{"A"}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}
                            },
                            jsx::array_t{
                                jsx::string_t{""}, jsx::string_t{"B"}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}
                            },
                            jsx::array_t{
                                jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{"C"}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}
                            },
                            jsx::array_t{
                                jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{"A"}, jsx::string_t{""}, jsx::string_t{""}
                            },
                            jsx::array_t{
                                jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{"B"}, jsx::string_t{""}
                            },
                            jsx::array_t{
                                jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{""}, jsx::string_t{"C"}
                            }
                        }
                    }, {
                        jsx::string_t{"functions"}, jsx::string_t{"hyb.json"}
                    }
                }
            }, {
                jsx::string_t{"mu"}, mu
            }, {
                jsx::string_t{"beta"}, beta
            }, {
                jsx::string_t{"thermalisation time"}, jsx::int64_t{15}
            }, {
                jsx::string_t{"measurement time"}, jsx::int64_t{45}
            }, {
                jsx::string_t{"complex"}, jsx::boolean_t{std::is_same<Value, complex>::value}
            }, {
                jsx::string_t{"partition"}, jsx::object_t{
                    {
                        jsx::string_t{"quantum numbers"}, jsx::object_t{
                            {
                                jsx::string_t{"N"}, jsx::array_t({jsx::real64_t{1.}, jsx::real64_t{1.}, jsx::real64_t{1.}, jsx::real64_t{1.}, jsx::real64_t{1.}, jsx::real64_t{1.}})
                            },
                            {
                                jsx::string_t{"Sz"}, jsx::array_t({jsx::real64_t{.5}, jsx::real64_t{.5}, jsx::real64_t{.5}, jsx::real64_t{-.5}, jsx::real64_t{-.5}, jsx::real64_t{-.5}})
                            }
                        }
                    }, {
                        jsx::string_t{"green basis"}, jsx::string_t{"matsubara"}
                    }, {
                        jsx::string_t{"green matsubara cutoff"}, jsx::int64_t{25}
                    }, {
                        jsx::string_t{"green bulla"}, jsx::boolean_t{false}
                    }, {
                        jsx::string_t{"quantum number susceptibility"}, jsx::boolean_t{true}
                    }, {
                        jsx::string_t{"occupation susceptibility direct"}, jsx::boolean_t{true}
                    }, {
                        jsx::string_t{"occupation susceptibility bulla"}, jsx::boolean_t{false}
                    }, {
                        jsx::string_t{"susceptibility cutoff"}, jsx::int64_t{50}
                    }, {
                        jsx::string_t{"susceptibility tail"}, jsx::int64_t{200}
                    }
                }
            }, {
                jsx::string_t{"susc_ph"} , jsx::object_t{
                    {
                        jsx::string_t{"basis"}, jsx::string_t{"matsubara"}
                    }, {
                        jsx::string_t{"cutoff"}, jsx::int64_t{50}
                    }
                }
            }
        };
        
        
        
        mpi::write(jParams, "params.json");
    }
    
    
    {
        jsx::value jTensor = jsx::object_t{
            {
                jsx::string_t{"one body"}, pretty(get_one_body(loc, mu, hyb, bath))
            }, {
                jsx::string_t{"two body"}, get_two_body<Value>(loc.I() + bath.I(), interaction)
            }
        };
        
        jsx::value jHloc = ga::construct_hloc<Value>(jTensor);
        jsx::value jOperators = ga::construct_annihilation_operators<Value>(jHloc);
        
        
        
        {
            int const N = 50;
            
            std::ofstream file("green.txt");
            
            for(int n = 0; n <= N; ++n) {
                complex const z{.0, M_PI*(2*n + 1)/beta};
                
                std::cout << z.imag() << std::endl;
                
                file << z.imag();
                
                for(int i = 0; i < 3; ++i) {
                    complex const green = get_green_matsubara<Value>(beta, z, jHloc, jOperators(i), jOperators(i));
                    file << " " << green.real() << " " << green.imag();
                }
                
                file << std::endl;
            }
            
            file.close();
        }
        
        /*
        {
            jsx::value jn = jsx::array_t(loc.I(), jsx::array_t(loc.J()));
            
            for(int i = 0; i < loc.I(); ++i)
                for(int j = 0; j < loc.J(); ++j)
                    linalg::mult<Value>('c', 'n', 1., jOperators(i), jOperators(j), .0, jn(i)(j));

            
            int const N = 10;
            
            jsx::value jSusc;
            
            for(int i = 0; i < loc.I(); ++i)
                for(int j = 0; j < loc.J(); ++j)
                    for(int k = 0; k < loc.I(); ++k)
                        for(int l = 0; l < loc.J(); ++l)
                            if(surviving(jn(i)(j), jn(l)(k))) {
                                auto const entry = std::to_string(2*i + 1) + "_" + std::to_string(2*j) + "_" + std::to_string(2*k + 1) + "_" + std::to_string(2*l);
                                
                                //std::cout << entry << std::endl;
                                
                                io::cvec function(N + 1, .0);
                                
                                for(int n = 1; n <= N; ++n)
                                    function[n] = get_susc_matsubara<Value>(beta, complex{.0, M_PI*2*n/beta}, jHloc, jn(i)(j), jn(l)(k));
                                
                                
                                double sum = .0;
                                
                                for(auto const x : function) sum += std::abs(x);
                                
                                sum /= N + 1.;
                                
                                if(sum > 1.e-15)
                                    jSusc[entry] = std::move(function);
                            }
            
            std::ofstream file("susc_ph.txt");

            for(int n = 1; n <= N; ++n) {
                file << M_PI*2*n/beta << " ";
                
         
                //for(std::size_t i = 0; i < 6; ++i)
                //    for(std::size_t j = 0; j < 6; ++j) {
                //        auto const entry = std::to_string(2*i + 1) + "_" + std::to_string(2*i) + "_" + std::to_string(2*j + 1) + "_" + std::to_string(2*j);
                //
                //        file << " " << jsx::at<io::cvec>(jSusc(entry))[n].real() << " " << jsx::at<io::cvec>(jSusc(entry))[n].imag() << " ";
                //    }
         
                
                
                for(auto& jFunction : jSusc.object())
                    file << jsx::at<io::cvec>(jFunction.second)[n].real() << " " << jsx::at<io::cvec>(jFunction.second)[n].imag() << " ";
                
                
                file << std::endl;
            }
            
            file.close();
        }
        */
        
        {
            jsx::value jn = jsx::array_t(loc.I(), jsx::array_t(loc.J()));
            
            for(int i = 0; i < loc.I(); ++i)
                for(int j = 0; j < loc.J(); ++j)
                    linalg::mult<Value>('n', 'n', 1., jOperators(i), jOperators(j), .0, jn(i)(j));
            
            
            int const N = 10;
            
            jsx::value jSusc;
            
            std::vector<std::string> names = {"1up", "2up", "3up", "1dw", "2dw", "3dw"};
            std::map<std::string, std::string> name_lookup;
            
            for(int i = 0; i < loc.I(); ++i)
                for(int j = 0; j < loc.J(); ++j)
                    for(int k = 0; k < loc.I(); ++k)
                        for(int l = 0; l < loc.J(); ++l)
                            if(surviving(jn(i)(j), jn(l)(k))) {
                                auto const entry = std::to_string(2*i) + "_" + std::to_string(2*j) + "_" + std::to_string(2*k + 1) + "_" + std::to_string(2*l + 1);
                                
                                //std::cout << entry << std::endl;
                                
                                name_lookup[entry] = names[i] + "_" + names[j] + "_" + names[k] + "_" + names[l] + ((i%3 == l%3 && j%3 == k%3) ? "" : "x");
                                
                                
                                io::cvec function(N + 1, .0);
                                
                                for(int n = 1; n <= N; ++n)
                                    function[n] = get_susc_matsubara<Value>(beta, complex{.0, M_PI*2*n/beta}, jHloc, jn(i)(j), jn(l)(k));
                                
                                double sum = .0;
                                
                                for(auto const x : function) sum += std::abs(x);
                                
                                sum /= N + 1.;
                                
                                if(sum > 1.e-15)
                                    jSusc[entry] = std::move(function);
                            }
            
            std::ofstream file("susc_pp.txt");
            
            int counter = 2;
            for(auto& jFunction : jSusc.object()) {
                std::cout << counter << " : " << name_lookup[jFunction.first] << std::endl;
                counter += 2;
            }
            
            for(int n = 1; n <= N; ++n) {
                file << M_PI*2*n/beta << " ";
                
                /*
                 for(std::size_t i = 0; i < 6; ++i)
                 for(std::size_t j = 0; j < 6; ++j) {
                 auto const entry = std::to_string(2*i + 1) + "_" + std::to_string(2*i) + "_" + std::to_string(2*j + 1) + "_" + std::to_string(2*j);
                 
                 file << " " << jsx::at<io::cvec>(jSusc(entry))[n].real() << " " << jsx::at<io::cvec>(jSusc(entry))[n].imag() << " ";
                 }
                 */

                for(auto& jFunction : jSusc.object())
                    file << jsx::at<io::cvec>(jFunction.second)[n].real() << " " << jsx::at<io::cvec>(jFunction.second)[n].imag() << " ";
                
                
                file << std::endl;
            }
            
            file.close();
        }

        
        {
            jsx::value jn = jsx::array_t(loc.I());
            
            for(int i = 0; i < loc.I(); ++i)
                linalg::mult<Value>('c', 'n', 1., jOperators(i), jOperators(i), .0, jn(i));
            

            std::ofstream file_occ("susc_occ.txt");
            std::ofstream file_qn("susc_qn.txt");
            
            int const N = 10;
            
            for(int n = 1; n <= N; ++n) {
                complex const z{.0, M_PI*2*n/beta};
                
                std::cout << z.imag() << std::endl;

                file_occ << z.imag();

                double sumN = .0, sumSz = .0;
                
                for(int i = 0; i < loc.I(); ++i)
                    for(int j = 0; j < loc.J(); ++j) {
                        double const temp = get_susc_matsubara<Value>(beta, z, jHloc, jn(i), jn(j)).real();
                        
                        file_occ << " " << temp;
                        
                        sumN += temp; sumSz += (i/3 == 0 ? 0.5 : -0.5)*(j/3 == 0 ? 0.5 : -0.5)*temp;
                    }
                
                file_occ << std::endl;
                
                file_qn << z.imag() << " " << sumN << " " << sumSz << std::endl;
            }
            
            file_occ.close();
            file_qn.close();
        }
        
        
        {
            jsx::value jn = jsx::array_t(3);
            
            for(int i = 0; i < 3; ++i)
                linalg::mult<Value>('c', 'n', 1., jOperators(i), jOperators(i), .0, jn(i));
            
            std::ofstream file_occ("occ.txt");
            
            for(int i = 0; i < 3; ++i)
                file_occ << get_observable<Value>(beta, jHloc, jn(i)) << " ";

            file_occ.close();
        }
        
    }
};

#endif
