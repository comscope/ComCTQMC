#ifndef BENCHMARK_KANAMORI_OPTION_H
#define BENCHMARK_KANAMORI_OPTION_H

#include "Kanamori.h"
#include "../../include/Utilities.h"
#include "../../include/Green.h"
#include "../../include/Susc.h"
#include "../../include/Hyb.h"
#include "../../include/Observable.h"
#include "../../../include/mpi/Utilities.h"
#include "../../../include/linalg/Operators.h"


template<typename ValueL, typename ValueR>
io::Matrix<decltype(ValueL()*ValueR())> transform(io::Matrix<ValueL> transformation, io::Matrix<ValueR> arg) {
    using namespace benchmark;
    
    io::Matrix<decltype(ValueL()*ValueR())> temp(transformation.I(), transformation.J());
    
    for(int a = 0; a < transformation.I(); ++a)
        for(int b = 0; b < transformation.J(); ++b)
            for(int i = 0; i < transformation.I(); ++i)
                for(int j = 0; j < transformation.J(); ++j)
                    temp(a, b) += conj(transformation(a, i))*arg(i, j)*transformation(b, j);
    
    return temp;
}


template<typename ValueL, typename ValueR>
io::Matrix<decltype(ValueL()*ValueR())> transformCov(io::Matrix<ValueL> transformation, io::Matrix<ValueR> arg) {
    using namespace benchmark;
    
    io::Matrix<decltype(ValueL()*ValueR())> temp(transformation.I(), transformation.J());
    
    for(int a = 0; a < transformation.I(); ++a)
        for(int b = 0; b < transformation.J(); ++b)
            for(int i = 0; i < transformation.I(); ++i)
                for(int j = 0; j < transformation.J(); ++j)
                    temp(a, b) += transformation(a, i)*arg(i, j)*conj(transformation(b, j));
    
    return temp;
}


double get_phase(double phi, double) {
    return 1.;
}

std::complex<double> get_phase(double phi, std::complex<double>) {
    return std::complex<double>{std::cos(phi), std::sin(phi)};
}



template<typename Value>
void make_option() {
    using namespace benchmark;

    
    double const U = 4, J = U/4., lambda = std::sqrt(U), beta = 10, mu = 5./2.*U - 5.*J, eloc = 0.5, ebath = 1.;
    
    double const theta = 2*M_PI*15./360, phi = 2*M_PI*45./360.;
    
    
    
    auto const loc = get_matrix<Value>
    ({
        {  .0,    .0,    .0,    .0,    .0,    .0},
        {  .0,  eloc,    .0,    .0,    .0,    .0},
        {  .0,    .0, -eloc,    .0,    .0,    .0},
        {  .0,    .0,    .0,    .0,    .0,    .0},
        {  .0,    .0,    .0,    .0,  eloc,    .0},
        {  .0,    .0,    .0,    .0,    .0, -eloc}
    });
    
    Kanamori interaction(loc.I(), U, J);
    
    
    auto const hyb = get_matrix<Value>
    ({
        {  lambda,      .0,      .0,      .0,      .0,      .0},
        {      .0,  lambda,      .0,      .0,      .0,      .0},
        {      .0,      .0,  lambda,      .0,      .0,      .0},
        {      .0,      .0,      .0,  lambda,      .0,      .0},
        {      .0,      .0,      .0,      .0,  lambda,      .0},
        {      .0,      .0,      .0,      .0,      .0,  lambda}
    });
    
    auto const bath = get_matrix<Value>
    ({
        {  .0,     .0,     .0,     .0,     .0,     .0},
        {  .0,  ebath,     .0,     .0,     .0,     .0},
        {  .0,     .0, -ebath,     .0,     .0,     .0},
        {  .0,     .0,     .0,     .0,     .0,     .0},
        {  .0,     .0,     .0,     .0,  ebath,     .0},
        {  .0,     .0,     .0,     .0,     .0, -ebath}
    });
    
    Value const phase = get_phase(phi, Value());
    
    auto const transformation = get_matrix<Value>
    ({
        {  1.,                    .0,                          .0,  .0,                     .0,                          .0},
        {  .0, phase*std::cos(theta),             std::sin(theta),  .0,                     .0,                          .0},
        {  .0,      -std::sin(theta), conj(phase)*std::cos(theta),  .0,                     .0,                          .0},
        {  .0,                    .0,                          .0,  1.,                     .0,                          .0},
        {  .0,                    .0,                          .0,  .0,  phase*std::cos(theta),             std::sin(theta)},
        {  .0,                    .0,                          .0,  .0,       -std::sin(theta), conj(phase)*std::cos(theta)}
    });
    
    

    {
        auto const function = get_hyb(beta, 50, transform(transformation, hyb), transform(transformation, bath));

        jsx::value jHyb = jsx::object_t
        {
            {
                jsx::string_t{"0_0"}, function[0][0]
            },
            {
                jsx::string_t{"1_1"}, function[1][1]
            },
            {
                jsx::string_t{"1_2"}, function[1][2]
            },
            {
                jsx::string_t{"2_1"}, function[2][1]
            },
            {
                jsx::string_t{"2_2"}, function[2][2]
            }
        };
        
        mpi::write(jHyb, "hyb.json");
        
        
        jsx::value jParams = jsx::object_t
        {
            /*
            {
                jsx::string_t{"basis"}, jsx::object_t{
                    {
                        jsx::string_t{"orbitals"}, jsx::int64_t(3)
                    },
                    {
                        jsx::string_t{"transformation"}, pretty(transformation)
                    }
                }
            },
            {
                jsx::string_t{"hloc"}, jsx::object_t{
                    {
                        jsx::string_t{"one body"}, pretty(transform(transformation, loc))
                    }, {
                        jsx::string_t{"two body"}, jsx::object_t{
                            {
                                jsx::string_t{"parametrisation"}, jsx::string_t{"kanamori"}
                            }, {
                                jsx::string_t{"U"}, jsx::real64_t{U}
                            }, {
                                jsx::string_t{"J"}, jsx::real64_t{J}
                            }, {
                                jsx::string_t{"approximation"}, jsx::string_t{"none"}
                            }
                        }
                    }
                }
            },
            */
            {
                jsx::string_t{"basis"}, jsx::object_t{
                    {
                        jsx::string_t{"type"}, jsx::string_t{"product real"}
                    },
                    {
                        jsx::string_t{"orbitals"}, jsx::string_t{"p"}
                    },
                    {
                        jsx::string_t{"transformation"}, pretty(transformation)
                    }
                }
            },
            {
                jsx::string_t{"hloc"}, jsx::object_t{
                    {
                        jsx::string_t{"one body"}, pretty(transform(transformation, loc))
                    }, {
                        jsx::string_t{"two body"}, jsx::object_t{
                            {
                                jsx::string_t{"parametrisation"}, jsx::string_t{"slater-condon"}
                            }, {
                                jsx::string_t{"F0"}, jsx::real64_t{U - 4./3.*J}
                            }, {
                                jsx::string_t{"F2"}, jsx::real64_t{25./3.*J}
                            }, {
                                jsx::string_t{"approximation"}, jsx::string_t{"none"}
                            }
                        }
                    }
                }
            },
            {
                jsx::string_t{"hybridisation"}, jsx::object_t{
                    {
                        jsx::string_t{"matrix"}, jsx::array_t{
                            jsx::array_t{
                                jsx::string_t{"0_0"},    jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""}
                            },
                            jsx::array_t{
                                   jsx::string_t{""}, jsx::string_t{"1_1"}, jsx::string_t{"1_2"},    jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""}
                            },
                            jsx::array_t{
                                   jsx::string_t{""}, jsx::string_t{"2_1"}, jsx::string_t{"2_2"},    jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""}
                            },
                            jsx::array_t{
                                   jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""}, jsx::string_t{"0_0"},    jsx::string_t{""},    jsx::string_t{""}
                            },
                            jsx::array_t{
                                   jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""}, jsx::string_t{"1_1"}, jsx::string_t{"1_2"}
                            },
                            jsx::array_t{
                                   jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""},    jsx::string_t{""}, jsx::string_t{"2_1"}, jsx::string_t{"2_2"}
                            }
                        }
                    }, {
                        jsx::string_t{"functions"}, jsx::string_t{"hyb.json"}
                    }
                }
            }, {
                jsx::string_t{"mu"}, mu
            }, {
                jsx::string_t{"beta"}, beta
            }, {
                jsx::string_t{"thermalisation time"}, jsx::int64_t{15}
            }, {
                jsx::string_t{"measurement time"}, jsx::int64_t{45}
            }, {
                jsx::string_t{"complex"}, jsx::boolean_t{std::is_same<Value, complex>::value}
            }, {
                jsx::string_t{"partition"}, jsx::object_t{
                    {
                        jsx::string_t{"quantum numbers"}, jsx::object_t{
                            {
                                jsx::string_t{"N"}, jsx::object_t()
                            },
                            {
                                jsx::string_t{"Sz"}, jsx::object_t()
                            }
                        }
                    }, {
                        jsx::string_t{"green basis"}, jsx::string_t{"matsubara"}
                    }, {
                        jsx::string_t{"green matsubara cutoff"}, jsx::int64_t{25}
                    }, {
                        jsx::string_t{"green bulla"}, jsx::boolean_t{false}
                    }, {
                        jsx::string_t{"quantum number susceptibility"}, jsx::boolean_t{true}
                    }, {
                        jsx::string_t{"occupation susceptibility direct"}, jsx::boolean_t{false}
                    }, {
                        jsx::string_t{"occupation susceptibility bulla"}, jsx::boolean_t{false}
                    }, {
                        jsx::string_t{"susceptibility cutoff"}, jsx::int64_t{50}
                    }, {
                        jsx::string_t{"susceptibility tail"}, jsx::int64_t{200}
                    }
                }
            }
        };
        
        mpi::write(jParams, "params.json");
    }
    
    
    {
        jsx::value jTensor = jsx::object_t{
            {
                jsx::string_t{"one body"}, pretty(get_one_body(loc, mu, hyb, bath))
            }, {
                jsx::string_t{"two body"}, get_two_body<Value>(loc.I() + bath.I(), interaction)
            }
        };
        
        jsx::value jHloc = ga::construct_hloc<Value>(jTensor);
        jsx::value jOperators = ga::construct_annihilation_operators<Value>(jHloc);
        

        {
            int const N = 100;
            
            std::ofstream file("green.txt");
            
            for(int n = 0; n <= N; ++n) {
                complex const z{.0, M_PI*(2*n + 1)/beta};
                
                std::cout << z.imag() << std::endl;
                
                io::cmat green(loc.I(), loc.J());
                
                for(int i = 0; i < loc.I(); ++i)
                    for(int j = 0; j < loc.J(); ++j)
                        green(i, j) = get_green_matsubara<Value>(beta, z, jHloc, jOperators(i), jOperators(j));
                
                auto const green_transf = transform(transformation, green);
                
                file << z.imag() << " "
                << green_transf(0, 0).real() << " " << green_transf(0, 0).imag() << " "
                << green_transf(1, 1).real() << " " << green_transf(1, 1).imag() << " "
                << green_transf(1, 2).real() << " " << green_transf(1, 2).imag() << " "
                << green_transf(2, 1).real() << " " << green_transf(2, 1).imag() << " "
                << green_transf(2, 2).real() << " " << green_transf(2, 2).imag() << std::endl;
            }
            
            
            file.close();
        }
        
        
        {
            jsx::value jn = jsx::array_t(loc.I());
            
            for(int i = 0; i < loc.I(); ++i)
                linalg::mult<Value>('c', 'n', 1., jOperators(i), jOperators(i), .0, jn(i));

            
            std::ofstream file_qn("susc_qn.txt");
            
            int const N = 50;
            
            for(int n = 1; n <= N; ++n) {
                complex const z{.0, M_PI*2*n/beta};
                
                std::cout << z.imag() << std::endl;

                double sumN = .0, sumSz = .0;
                
                for(int i = 0; i < loc.I(); ++i)
                    for(int j = 0; j < loc.J(); ++j) {
                        double const temp = get_susc_matsubara<Value>(beta, z, jHloc, jn(i), jn(j)).real();

                        sumN += temp; sumSz += (i/3 == 0 ? 0.5 : -0.5)*(j/3 == 0 ? 0.5 : -0.5)*temp;
                    }

                file_qn << z.imag() << " " << sumN << " " << sumSz << std::endl;
            }
            
            file_qn.close();
        }

        
        {
            jsx::value jn = jsx::array_t(loc.I(), jsx::array_t(loc.J()));

            for(int i = 0; i < loc.I(); ++i)
                for(int j = 0; j < loc.J(); ++j)
                    linalg::mult<Value>('c', 'n', 1., jOperators(i), jOperators(j), .0, jn(i)(j));

            io::Matrix<Value> occ(loc.I(), loc.J());
            
            for(int i = 0; i < loc.I(); ++i)
                for(int j = 0; j < loc.J(); ++j)
                    occ(i, j) = get_observable<Value>(beta, jHloc, jn(i)(j));
            
            io::Matrix<Value> occ_transf = transformCov(transformation, occ);

            std::ofstream file_occ("occ.txt");
            
            file_occ
            << occ_transf(0, 0) << " "
            << occ_transf(1, 1) << " "
            << occ_transf(1, 2) << " "
            << occ_transf(2, 1) << " "
            << occ_transf(2, 2)
            << std::endl;

            file_occ.close();
        }
        
    }
    
};

#endif

