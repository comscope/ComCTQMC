#include "Option.h"


int main(int argc, char** argv) {
    
    make_option<std::complex<double>>();
    
};

