#ifndef BENCHMARK_KANAMORI_SHINAOKA_KANAMORI_H
#define BENCHMARK_KANAMORI_SHINAOKA_KANAMORI_H

#include <stdexcept>

namespace benchmark {
    
    struct Kanamori {
        Kanamori() = delete;
        Kanamori(int N, double U, double J) :
        N_(N),
        U_(U),
        J_(J),
        Up_(U_ - 2.*J_) {
            if(N%2) throw std::runtime_error("Kanamori: wrong dimension!");
        }
        ~Kanamori() = default;
        
        double operator()(int f1, int f2, int f3, int f4) const {
            if(!((f1%2 == f4%2) && (f2%2 == f3%2))) return .0;
            
            int const m1 = f1/2, m2 = f2/2, m3 = f3/2, m4 = f4/2;
            
            if(m1 == m2 && m3 == m4 && m1 == m3) return U_;
            if(m1 == m4 && m2 == m3 && m1 != m2) return Up_;
            if(m1 == m3 && m2 == m4 && m1 != m2) return J_;
            if(m1 == m2 && m3 == m4 && m1 != m3) return J_;
            
            return .0;
        };
        
        int N() const {
            return N_;
        };
        
    private:
        int const N_;
        double const U_, J_, Up_;
    };
    
}

#endif
