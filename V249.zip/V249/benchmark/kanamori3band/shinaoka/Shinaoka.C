#include "Kanamori.h"
#include "../../include/Utilities.h"
#include "../../include/Green.h"
#include "../../include/Susc.h"
#include "../../include/Hyb.h"
#include "../../include/Observable.h"
#include "../../../include/mpi/Utilities.h"
#include "../../../include/linalg/Operators.h"


int main(int argc, char** argv) {
    
    using Value = std::complex<double>;
    using namespace benchmark;

    
    
    double const U = 10., J = U/4., tp = .2, zeta = 1., lambda = 1., beta = 10, mu = 5./2.*U - 5.*J;
    
    
    
    std::complex<double> const _i(.0, zeta/2.), _1(zeta/2.);
    
    auto const loc = get_matrix<Value>
    ({
        {  .0,  .0,  .0,  _1,  .0, -_i},
        {  .0,  .0, -_1,  .0, -_i,  .0},
        {  .0, -_1,  .0,  .0,  _i,  .0},
        {  _1,  .0,  .0,  .0,  .0, -_i},
        {  .0,  _i, -_i,  .0,  .0,  .0},
        {  _i,  .0,  .0,  _i,  .0,  .0}
    });
    
    Kanamori interaction(loc.I(), U, J);
    
    
    auto const hyb = get_matrix<Value>
    ({
        { lambda, .0, .0, .0, .0, .0},
        { .0, lambda, .0, .0, .0, .0},
        { .0, .0, lambda, .0, .0, .0},
        { .0, .0, .0, lambda, .0, .0},
        { .0, .0, .0, .0, lambda, .0},
        { .0, .0, .0, .0, .0, lambda}
    });
    
    auto const bath = get_matrix<Value>
    ({
        { .0, .0, tp, .0, tp, .0},
        { .0, .0, .0, tp, .0, tp},
        { tp, .0, .0, .0, tp, .0},
        { .0, tp, .0, .0, .0, tp},
        { tp, .0, tp, .0, .0, .0},
        { .0, tp, .0, tp, .0, .0}
    });

    
    {
        jsx::value jTensor = jsx::object_t{
            {
                jsx::string_t{"one body"}, pretty(get_one_body(loc, mu, hyb, bath))
            }, {
                jsx::string_t{"two body"}, get_two_body<Value>(loc.I() + bath.I(), interaction)
            }
        };
        
        jsx::value jHloc = ga::construct_hloc<Value>(jTensor);
        jsx::value jOperators = ga::construct_annihilation_operators<Value>(jHloc);
        

        {
            int const N = 51;
            
            std::ofstream file("green.txt");
            
            for(int n = 0; n <= N; ++n) {
                double const x = n/(5.*N);
                
                std::cout << x << std::endl;
                
                file << x;
                
                for(int i = 0; i < loc.I(); ++i) {
                    complex const green = get_green_tau<Value>(beta, x*beta, jHloc, jOperators(0), jOperators(i));
                    file << " " << green.real() << " " << green.imag();
                }
                
                file << std::endl;
            }
            
            file.close();
        }
  
    }
    
};
