#ifndef BENCHMARK_HUBBARD_H
#define BENCHMARK_HUBBARD_H

#include <stdexcept>

namespace benchmark {
    
    struct Hubbard {
        Hubbard() = delete;
        Hubbard(int N, double U) :
        n_(N/2),
        U_(U) {
            if(N%2) throw std::runtime_error("Kanamori: wrong dimension!");
        }
        ~Hubbard() = default;
        
        double operator()(int f1, int f2, int f3, int f4) const {
            if(!((f1/n_ == f4/n_) && (f2/n_ == f3/n_) && (f1/n_ != f2/n_))) return .0;
            if(!((f1%n_ == f4%n_) && (f2%n_ == f3%n_) && (f1%n_ == f2%n_))) return .0;

            return U_;
        };
        
        int N() const {
            return 2*n_;
        };
        
    private:
        int const n_;
        double const U_;
    };
    
}

#endif
