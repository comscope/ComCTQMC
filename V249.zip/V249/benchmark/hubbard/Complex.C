#include "Basic.h"


int main(int argc, char** argv) {
    
    make_basic<std::complex<double>>();
    
};

