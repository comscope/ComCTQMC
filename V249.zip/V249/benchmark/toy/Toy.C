#include "Toy.h"

#include "../include/Utilities.h"
#include "../include/Green.h"
#include "../include/Susc.h"
#include "../include/Hyb.h"
#include "../include/Observable.h"

#include "../../include/mpi/Utilities.h"
#include "../../include/linalg/Operators.h"


int main(int argc, char** argv) {
    
    using namespace benchmark;

    
    using Value = complex;
    
    
    
    double const lambda = 1., eps = 1., t = .25, Ua = 3., Ub = 1., Uc = 3.;
    
    double const phi_tl = 2*M_PI*0.82, phi_tb = 2*M_PI*0.13, phi_Uc = 2*M_PI*0.72;
    
    
    complex const _i{.0, 1.};

    complex const _tl = std::exp(_i*phi_tl)*t;  complex const _tlc = conj(_tl);
    complex const _tb = std::exp(_i*phi_tb)*t;  complex const _tbc = conj(_tb);
    complex const _Uc = std::exp(_i*phi_Uc)*Uc;
    
    
    double const beta = 25;
    
    double const mu = Ua/2. - Ub/2.;
   
    

    auto const loc = get_matrix<Value>
    ({
        {  .0,   .0,  .0 },
        {  .0,   .0, _tl },
        {  .0, _tlc,  .0 }
    });
    
    Toy<Value> interaction(loc.I(), Ua, Ub, _Uc);

    
    auto const hyb = get_matrix<Value>
    ({
        { lambda, lambda, lambda,     .0,     .0,     .0,     .0,     .0,     .0 },
        {     .0,     .0,     .0, lambda, lambda, lambda,     .0,     .0,     .0 },
        {     .0,     .0,     .0,     .0,     .0,     .0, lambda, lambda, lambda }
    });
    
    auto const bath = get_matrix<Value>
    ({
        { -eps,   .0,   .0,   .0,   .0,   .0,   .0,   .0,   .0 },
        {   .0,   .0,   .0,   .0,   .0,   .0,   .0,   .0,   .0 },
        {   .0,   .0,  eps,   .0,   .0,   .0,   .0,   .0,   .0 },
        {   .0,   .0,   .0, -eps,   .0,   .0,  _tb,   .0,   .0 },
        {   .0,   .0,   .0,   .0,   .0,   .0,   .0,  _tb,   .0 },
        {   .0,   .0,   .0,   .0,   .0,  eps,   .0,   .0,  _tb },
        {   .0,   .0,   .0, _tbc,   .0,   .0, -eps,   .0,   .0 },
        {   .0,   .0,   .0,   .0, _tbc,   .0,   .0,   .0,   .0 },
        {   .0,   .0,   .0,   .0,   .0, _tbc,   .0,   .0,  eps }
    });
    

    {
        auto const function = get_hyb(beta, 50, hyb, bath);
        
        jsx::value jFunctions = jsx::object_t
        {
            {
                jsx::string_t{"0_0"}, function[0][0]
            },
            {
                jsx::string_t{"1_1"}, function[1][1]
            },
            {
                jsx::string_t{"1_2"}, function[1][2]
            },
            {
                jsx::string_t{"2_1"}, function[2][1]
            },
            {
                jsx::string_t{"2_2"}, function[2][2]
            }
        };
        
        mpi::write(jFunctions, "hyb.json");
        
        
        jsx::value jParams = jsx::object_t
        {
            {
                jsx::string_t{"hloc"}, jsx::object_t{
                    {
                        jsx::string_t{"one body"}, pretty(loc)
                    }, {
                        jsx::string_t{"two body"}, get_two_body<Value>(loc.I(), interaction)
                    }
                }
            }, {
                jsx::string_t{"hybridisation"}, jsx::object_t{
                    {
                        jsx::string_t{"matrix"}, jsx::array_t{
                            jsx::array_t{
                                jsx::string_t{"0_0"}, jsx::string_t{""}, jsx::string_t{""},
                            },
                            jsx::array_t{
                                jsx::string_t{""}, jsx::string_t{"1_1"}, jsx::string_t{"1_2"},
                            },
                            jsx::array_t{
                                jsx::string_t{""}, jsx::string_t{"2_1"}, jsx::string_t{"2_2"}
                            }
                        }
                    }, {
                        jsx::string_t{"functions"}, jsx::string_t{"hyb.json"}
                    }
                }
            }, {
                jsx::string_t{"mu"}, mu
            }, {
                jsx::string_t{"beta"}, beta
            }, {
                jsx::string_t{"thermalisation time"}, jsx::int64_t{5}
            }, {
                jsx::string_t{"measurement time"}, jsx::int64_t{20}
            }, {
                jsx::string_t{"complex"}, jsx::boolean_t{true}
            }, {
                jsx::string_t{"partition"}, jsx::object_t{
                    {
                        jsx::string_t{"quantum numbers"}, jsx::object_t{
                            {
                                jsx::string_t{"N"}, jsx::array_t({jsx::real64_t{1.}, jsx::real64_t{1.}, jsx::real64_t{1.}})
                            }
                        }
                    }, {
                        jsx::string_t{"green basis"}, jsx::string_t{"matsubara"}
                    }, {
                        jsx::string_t{"green matsubara cutoff"}, jsx::int64_t{25}
                    }, {
                        jsx::string_t{"green bulla"}, jsx::boolean_t{true}
                    }, {
                        jsx::string_t{"quantum number susceptibility"}, jsx::boolean_t{true}
                    }, {
                        jsx::string_t{"occupation susceptibility direct"}, jsx::boolean_t{true}
                    }, {
                        jsx::string_t{"occupation susceptibility bulla"}, jsx::boolean_t{false}
                    }, {
                        jsx::string_t{"susceptibility cutoff"}, jsx::int64_t{50}
                    }, {
                        jsx::string_t{"susceptibility tail"}, jsx::int64_t{200}
                    }
                }
            }
        };
        
        mpi::write(jParams, "params.json");
    }
    
    
    {
        jsx::value jTensor = jsx::object_t{
            {
                jsx::string_t{"one body"}, pretty(get_one_body(loc, mu, hyb, bath))
            }, {
                jsx::string_t{"two body"}, get_two_body<Value>(loc.I() + bath.I(), interaction)
            }
        };
        
        jsx::value jHloc = ga::construct_hloc<Value>(jTensor);
        jsx::value jOperators = ga::construct_annihilation_operators<Value>(jHloc);

        {
            int const N = 100;
            
            std::ofstream file("green.txt");
            
            for(int n = 0; n <= N; ++n) {
                complex const z{.0, M_PI*(2*n + 1)/beta};
                
                std::cout << z.imag() << std::endl;
                
                file << z.imag();
                
                std::vector<std::pair<int, int>> indices = {{0, 0}, {1, 1}, {1, 2}, {2, 1}, {2, 2}};
                
                for(auto index : indices) {
                    complex const green = get_green_matsubara<Value>(beta, z, jHloc, jOperators(index.first), jOperators(index.second));
                    file << " " << green.real() << " " << green.imag();
                }
                
                file << std::endl;
            }
            
            file.close();
        }
        
        /*
        {
            jsx::value jn = jsx::array_t(loc.I());
            
            for(int i = 0; i < loc.I(); ++i)
                linalg::mult<Value>('c', 'n', 1., jOperators(i), jOperators(i), .0, jn(i));
            
            
            int const N = 30;
            
            std::ofstream fileNN("susc_NN.txt");
            std::ofstream fileOcc("susc_occ.txt");
            
            for(int n = 1; n <= N; ++n) {
                complex const z{.0, M_PI*2*n/beta};
                
                std::cout << z.imag() << std::endl;
                
                fileOcc << z.imag();
                
                double sum = .0;
                for(int i = 0; i < loc.I(); ++i)
                    for(int j = 0; j < loc.J(); ++j) {
                        double temp = get_susc_matsubara<Value>(beta, z, jHloc, jn(i), jn(j)).real();
                        
                        fileOcc << " " << temp;
                        
                        sum += temp;
                        
                    }
                
                
                fileOcc << std::endl;
                fileNN << z.imag() << " " << sum << std::endl;
            }
            
            fileNN.close();
            fileOcc.close();
            
        }
        */
        
        
    }
    
};

