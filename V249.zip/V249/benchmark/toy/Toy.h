#ifndef BENCHMARK_TOY_H
#define BENCHMARK_TOY_H

#include "../include/Zahl.h"

namespace benchmark {
    
    template<typename Value>
    struct Toy {
        Toy() = delete;
        Toy(int N, double A, double B, Value C) :
        N_(N), A_(A), B_(B), C_(C) {
        }
        ~Toy() = default;
        
        Value operator()(int f1, int f2, int f3, int f4) const {
            if( f1 == f4 && f2 == f3 && f1 == f2) return A_;
            if( f1 == f4 && f2 == f3 && f1 != f2) return B_;
            if( f1 == 0 && f4 == 0 && f2 == 1 && f3 == 2) return C_;
            if( f1 == 0 && f4 == 0 && f2 == 2 && f3 == 1) return conj(C_);
            return .0;
        };
        
        int N() const {
            return N_;
        };
        
    private:
        int const N_;
        double const A_, B_;
        Value const C_;
    };
    
}

#endif
