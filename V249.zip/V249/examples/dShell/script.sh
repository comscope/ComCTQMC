#!/bin/bash

#set -x

########################################################################

#   Grid Engine Job Wrapper

########################################################################

#$ -N  GuckschDu!

#$ -pe orte 1

#$ -q  bnlg

#$ -j  y

#$ -v PATH,LD_LIBRARY_PATH,OMP_NUM_THREADS,MODULEPATH

########################################################################

# DON'T remove the following line!

source $TMPDIR/sge_init.sh

########################################################################

export OMP_NUM_THREADS=1

export SMPD_OPTION_NO_DYNAMIC_HOSTS=1

export MODULEPATH=/opt/apps/modulefiles:/opt/intel/modulefiles:/opt/pgi/modulefiles:/opt/gnu/modulefiles:/opt/sw/modulefiles

module load   intel/18.0  intel/ompi

mpirun    -n $NSLOTS ~/ctqmc/device/CTQMC params > out 2>error
